from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from .models import Board
# Create your views here.

def index(request):

    result = None # 필터링 된 리스트
    context = {}
    # return render(request,'board/index.html')
    # 반환되는 queryset에 대해서 order_by함수 이용하면 특정 필드 기준으로 정렬
    # order_by에 들어가는 필드 앞에 -를 붙이면 내림차순(desc) 아니면 오름차순
    print(request.method)
    if 'searchType' in request.GET and 'searchWord' in request.GET:
        search_type = request.GET['searchType'] # get안의 문자열은 
        search_word = request.GET['searchWord'] # html의 name속성과 일치해야함
        print("searchType :{}, search_word : {}".format(search_type,search_word))

        #match:java의 switch와 비슷함
        match search_type:
            case 'title': # 검색 기준이 제목일때
                result = Board.objects.filter(title__contains = search_word)
            case 'writer': # 검색 기준이 제목일때
                result = Board.objects.filter(writer__contains = search_word)
            case 'content': # 검색 기준이 제목일때
                result = Board.objects.filter(content__contains = search_word)
        # 검색을 했을 때만 검색 기준과 키워드를 context에 넣는다
        context['searchType'] = search_type
        context['searchWord'] = search_word
    else: # QueryDict에 검색 조건과 키워드가 없을 때
        result = Board.objects.all()
        
    # 검색 결과 또는 전체 목록을 id의 내림차순
    result = result.order_by("-id")
    # board_list = Board.objects.all().order_by('-id')

    context['board_list'] =result
    return render(request,'board/index.html', context)

def read(request,id):
    print("read실행")
    # board = Board.objects.all()
    board = Board.objects.get(id = id)
    board.view_count += 1
    board.save()
    context ={
        'board':board
    }
    return render(request,'board/read.html', context)
    # return render(request,'board/board.html', context)

def home(request):
    # 목록으로
    return HttpResponseRedirect("/board/")

def write(request):
    if request.method =='GET': #요청방식이 get 방식이면 화면 표시
        return render(request,'board/board_form.html')
    else: # 요청방식이 POST일때 할일
        # 폼의 데이터를 DB에 저장
        title = request.POST['title']
        # writer = request.POST['writer'] #??
        content = request.POST['content']


        # 현재 세션정보에 writer라는 정보를 취득
        session_writer = request.session.get('writer')
        if not session_writer: #세션에 정보가 없는 경우
            # 폼에서 가져온 writer값 세션에 저장
            request.session['writer'] = request.POST["writer"]

        print(session_writer)
        
        # board = Board(
        #     title = title,
        #     writer = writer,
        #     content = content
        # )
        # board.save() #db에 insert

        Board.objects.create(
            title = title,
            writer = request.session.get('writer'), #세션에 있는 값 저장
            content = content
        )
        return HttpResponseRedirect('/board/')
    

def update(request,id):
    board = Board.objects.get(id=id)
    # 전송 방식에 따른 화면 표시
    if request.method == "GET":
    #id로 찾은 친구 정보를 템플릿에 표시하기 위해서 
        context = {'board' : board}
        return render(request,'Board/board_update.html', context)
    else:
        # id로 찾은 객체에 대해서 폼의 값으로 원래 객체의 값 덮어쓰기
        board.title = request.POST['title']
        board.writer = request.POST['writer']
        board.content = request.POST['content']
            
        board.save()
        #수정 후에 해당 글로 다시 이동
        redirect_url = '/board/' +str(id) +'/'
        
        return HttpResponseRedirect(redirect_url)
    # return HttpResponseRedirect('/board/')

def delete(request,id):
    print("id :",id)
    # 해당 객체를 가져와서 삭제
    Board.objects.get(id=id).delete()
    return HttpResponseRedirect('/board/')
