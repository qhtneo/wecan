from django.urls import path
from . import views

#여기는 board에 있는 urls.py다
urlpatterns = [
    path('', views.index),
    path('<int:id>/',views.read),
    path('write/',views.write),
    path('<int:id>/update/',views.update),
    path('<int:id>/delete/',views.delete),

]